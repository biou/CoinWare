﻿using UnityEngine;
using System.Collections;

public class RotateCube : MonoBehaviour {

    public float velocity = 15.0f;
    public Vector3 direction = new Vector3(1.0f, 2.0f, 0.0f);

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        transform.Rotate(direction * velocity * Time.deltaTime);
	}
}
