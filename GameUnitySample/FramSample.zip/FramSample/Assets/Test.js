﻿#pragma strict

function Start () {

}

function Update () {
	if (Input.GetKey("a")) {
		Application.ExternalCall("EndGame", "true//1");
	}
}